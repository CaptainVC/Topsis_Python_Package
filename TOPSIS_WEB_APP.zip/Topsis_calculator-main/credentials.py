## set email and password of the account from which you want to send email
## and also enable less secure app access in google account settings

email = "email"
password = "password"
