### Topsis_calculator
Emails the intial dataset with topsis score and corresponding ranks

**You will have to provide your email and password i.e. your source, from where you are sending this email 
and along with this, you will also have to upload the input data csv fileand provide intial weights and impacts
and last but not least, target email i.e. where the final dataset will be emailed**

### If you want to use the calculator, kindly write your source email and password in the 'credentials.py' file and then save and run it
